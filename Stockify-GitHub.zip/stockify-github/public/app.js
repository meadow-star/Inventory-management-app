const app = document.querySelector('#app');
const modalRoot = document.querySelector('#modal-root');
const toastRoot = document.querySelector('#toast-root');

const state = {
  user: null,
  products: [],
  summary: null,
  search: '',
  category: '',
  showNotifications: false,
  page: 'inventory',
  marketPrices: new Map(),
  marketLoading: new Set(),
};

const money = value => new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 2 }).format(Number(value || 0));
const number = value => new Intl.NumberFormat('en-IN').format(Number(value || 0));
const dateText = value => new Intl.DateTimeFormat('en-IN', { day: '2-digit', month: 'short', year: 'numeric' }).format(new Date(value));
const esc = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
const initials = name => String(name || 'U').split(/\s+/).filter(Boolean).slice(0,2).map(x => x[0]).join('').toUpperCase();
const safeUrl = value => { try { const u = new URL(value); return ['http:','https:'].includes(u.protocol) ? u.href : '#'; } catch { return '#'; } };

async function api(url, options = {}) {
  const response = await fetch(url, {
    credentials: 'include',
    headers: { ...(options.body ? { 'Content-Type': 'application/json' } : {}), ...(options.headers || {}) },
    ...options,
  });
  if (response.status === 204) return null;
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || 'Something went wrong.');
  return data;
}

function toast(message, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.innerHTML = `<span>${esc(message)}</span><button aria-label="Close">×</button>`;
  el.querySelector('button').onclick = () => el.remove();
  toastRoot.appendChild(el);
  setTimeout(() => el.remove(), 4200);
}

function icon(symbol) { return `<span aria-hidden="true">${symbol}</span>`; }

function renderAuth(mode = 'login') {
  app.innerHTML = `
    <main class="auth-shell">
      <section class="auth-brand">
        <div class="brand-mark"><span class="brand-logo">S</span><span>Stockify</span></div>
        <div class="brand-copy">
          <h1>Inventory that stays clear, calm and current.</h1>
          <p>Track stock, pricing and low-stock risk from one focused dashboard — with optional live Indian marketplace price comparisons.</p>
          <div class="brand-points"><span>Stock alerts</span><span>INR pricing</span><span>Market comparison</span><span>Responsive dashboard</span></div>
        </div>
        <small style="color:#738096;position:relative;z-index:1">Stockify Inventory Management</small>
      </section>
      <section class="auth-panel">
        <div class="auth-card">
          <h2>${mode === 'login' ? 'Welcome back' : 'Create your account'}</h2>
          <p class="sub">${mode === 'login' ? 'Sign in to open your inventory workspace.' : 'Set up your shop and start tracking stock.'}</p>
          <div class="auth-tabs">
            <button class="${mode === 'login' ? 'active' : ''}" data-auth-tab="login">Sign in</button>
            <button class="${mode === 'register' ? 'active' : ''}" data-auth-tab="register">Create account</button>
          </div>
          ${mode === 'login' ? `
            <form id="login-form">
              <div class="field"><label>Email</label><input class="input" name="email" type="email" autocomplete="email" required placeholder="you@example.com"></div>
              <div class="field"><label>Password</label><input class="input" name="password" type="password" autocomplete="current-password" required placeholder="••••••••"></div>
              <button class="btn btn-primary btn-block" type="submit">Sign in</button>
            </form>` : `
            <form id="register-form">
              <div class="form-grid">
                <div class="field"><label>Full name</label><input class="input" name="fullName" required placeholder="Your name"></div>
                <div class="field"><label>Mobile</label><input class="input" name="mobile" required placeholder="9876543210"></div>
              </div>
              <div class="field"><label>Email</label><input class="input" name="email" type="email" autocomplete="email" required placeholder="you@example.com"></div>
              <div class="field"><label>Shop name</label><input class="input" name="shopName" required placeholder="My Store"></div>
              <div class="field"><label>Password</label><input class="input" name="password" type="password" minlength="8" autocomplete="new-password" required placeholder="At least 8 characters"></div>
              <button class="btn btn-amber btn-block" type="submit">Create account</button>
            </form>`}
        </div>
      </section>
    </main>`;

  document.querySelectorAll('[data-auth-tab]').forEach(btn => btn.onclick = () => renderAuth(btn.dataset.authTab));
  const loginForm = document.querySelector('#login-form');
  if (loginForm) loginForm.onsubmit = async e => {
    e.preventDefault(); const button = loginForm.querySelector('button[type=submit]'); button.disabled = true; button.textContent = 'Signing in…';
    try {
      const form = new FormData(loginForm); const data = await api('/api/auth/login', { method:'POST', body: JSON.stringify(Object.fromEntries(form)) });
      state.user = data.user; await loadDashboardData(); renderDashboard(); toast('Signed in successfully.');
    } catch (err) { toast(err.message, 'error'); button.disabled = false; button.textContent = 'Sign in'; }
  };
  const regForm = document.querySelector('#register-form');
  if (regForm) regForm.onsubmit = async e => {
    e.preventDefault(); const button = regForm.querySelector('button[type=submit]'); button.disabled = true; button.textContent = 'Creating…';
    try {
      const form = new FormData(regForm); const data = await api('/api/auth/register', { method:'POST', body: JSON.stringify(Object.fromEntries(form)) });
      state.user = data.user; await loadDashboardData(); renderDashboard(); toast('Account created. Welcome to Stockify.');
    } catch (err) { toast(err.message, 'error'); button.disabled = false; button.textContent = 'Create account'; }
  };
}

async function loadDashboardData() {
  const [products, summary] = await Promise.all([api('/api/products'), api('/api/inventory/summary')]);
  state.products = products; state.summary = summary;
}

function filteredProducts() {
  const q = state.search.trim().toLowerCase();
  return state.products.filter(p => (!q || p.name.toLowerCase().includes(q) || p.productId.toLowerCase().includes(q)) && (!state.category || p.category === state.category));
}
function categories() { return [...new Set(state.products.map(p => p.category))].sort((a,b) => a.localeCompare(b)); }
function statusInfo(p) {
  if (p.quantity === 0) return { label:'Out', cls:'out', ratio:0 };
  if (p.quantity <= p.minimumStock) return { label:'Low', cls:'low', ratio: Math.max(8, Math.min(100, p.minimumStock ? (p.quantity / p.minimumStock) * 60 : 30)) };
  const base = Math.max(p.minimumStock * 3, p.quantity); return { label:'Healthy', cls:'ok', ratio: Math.min(100, (p.quantity / base) * 100) };
}
function stockMarkup(p) {
  const s = statusInfo(p);
  return `<div class="stock-row"><span class="stock-numbers">${number(p.quantity)} / min ${number(p.minimumStock)}</span><span class="stock-status status-${s.cls}">${s.label}</span></div><div class="stock-track"><div class="stock-fill fill-${s.cls}" style="width:${s.ratio}%"></div></div>`;
}
function marketMarkup(p, mobile = false) {
  const data = state.marketPrices.get(p.id); const loading = state.marketLoading.has(p.id);
  if (!data) return `<button class="btn btn-soft btn-sm" data-market="${p.id}" ${loading ? 'disabled' : ''}>${loading ? `${icon('↻')} Checking…` : `${icon('↗')} Check price`}</button>`;
  const diff = data.marketPrice - p.price; const pct = p.price > 0 ? (diff / p.price) * 100 : 0; const color = diff > 0 ? 'var(--teal)' : diff < 0 ? 'var(--red)' : 'var(--muted)';
  return `<div class="market-cell price-pulse"><div class="money">${money(data.marketPrice)} <button class="action-btn" data-market="${p.id}" title="Refresh market price" style="display:inline-grid;width:23px;height:23px;margin-left:3px">↻</button></div><div class="market-diff" style="color:${color}">${diff > 0 ? '+' : ''}${money(diff)} (${pct > 0 ? '+' : ''}${pct.toFixed(1)}%)</div><div class="market-meta"><span>${esc(data.platform)}</span>${data.productUrl ? `<a href="${esc(safeUrl(data.productUrl))}" target="_blank" rel="noreferrer">View</a>` : ''}</div></div>`;
}
function productRow(p, index) {
  return `<tr style="animation-delay:${Math.min(index * 28, 220)}ms">
    <td><div class="product-name">${esc(p.name)}</div><div class="product-id">${esc(p.productId)}</div></td>
    <td><span class="category-pill">${esc(p.category)}</span></td>
    <td style="min-width:150px">${stockMarkup(p)}</td>
    <td class="money">${money(p.price)}</td>
    <td>${marketMarkup(p)}</td>
    <td style="color:#7d8998;white-space:nowrap">${dateText(p.updatedAt)}</td>
    <td><div class="actions"><button class="action-btn" data-adjust="${p.id}" title="Adjust stock">±</button><button class="action-btn" data-edit="${p.id}" title="Edit">✎</button><button class="action-btn danger" data-delete="${p.id}" title="Delete">⌫</button></div></td>
  </tr>`;
}
function mobileProduct(p, index) {
  const s = statusInfo(p);
  return `<article class="mobile-product" style="animation-delay:${Math.min(index*30,210)}ms">
    <div class="mobile-product-head"><div><div class="product-name">${esc(p.name)}</div><div class="product-id">${esc(p.productId)}</div></div><span class="stock-status status-${s.cls}">${s.label}</span></div>
    <div class="mobile-meta"><div class="meta-box"><label>Category</label><strong>${esc(p.category)}</strong></div><div class="meta-box"><label>On hand</label><strong>${number(p.quantity)}</strong></div><div class="meta-box"><label>Your price</label><strong>${money(p.price)}</strong></div><div class="meta-box"><label>Minimum</label><strong>${number(p.minimumStock)}</strong></div></div>
    ${stockMarkup(p)}
    <div class="mobile-market"><div><div style="font-size:8px;text-transform:uppercase;letter-spacing:.08em;color:#8a96a6">Market price</div><div style="font-size:9px;color:#8a96a6;margin-top:3px">Live comparison</div></div>${marketMarkup(p, true)}</div>
    <div class="mobile-actions"><button class="btn btn-soft btn-sm" data-adjust="${p.id}">Adjust</button><button class="btn btn-soft btn-sm" data-edit="${p.id}">Edit</button><button class="btn btn-soft btn-sm" data-delete="${p.id}">Delete</button></div>
  </article>`;
}

function renderProductAreas() {
  const list = filteredProducts();
  const tbody = document.querySelector('#products-tbody'); const mobile = document.querySelector('#mobile-products'); const empty = document.querySelector('#empty-state');
  if (!tbody || !mobile || !empty) return;
  if (!list.length) {
    tbody.innerHTML = ''; mobile.innerHTML = ''; empty.classList.remove('hidden');
  } else {
    empty.classList.add('hidden'); tbody.innerHTML = list.map(productRow).join(''); mobile.innerHTML = list.map(mobileProduct).join('');
  }
  bindProductActions();
}

function renderBreakdown() {
  const el = document.querySelector('#breakdown-list'); if (!el || !state.summary) return;
  const rows = state.summary.categoryBreakdown || []; const max = Math.max(1, ...rows.map(r => r.value));
  el.innerHTML = rows.length ? rows.map((r,i) => `<div class="cat"><div class="cat-head"><strong>${esc(r.category)}</strong><span>${number(r.quantity)} units · ${money(r.value)}</span></div><div class="cat-track"><div class="cat-fill" style="width:${Math.max(6,(r.value/max)*100)}%;transition-delay:${i*50}ms"></div></div></div>`).join('') : `<p style="font-size:10px;color:var(--muted)">Add products to see category distribution.</p>`;
}

function notifications() { return state.products.filter(p => p.quantity <= p.minimumStock).sort((a,b)=>a.quantity-b.quantity); }
function updateNotificationPanel() {
  const old = document.querySelector('#notification-panel'); if (old) old.remove();
  if (!state.showNotifications) return;
  const items = notifications(); const panel = document.createElement('div'); panel.id='notification-panel'; panel.className='notification-panel';
  panel.innerHTML = `<div class="notify-head"><strong>Stock alerts</strong><span>${items.length} need attention</span></div>${items.length ? items.map(p => `<div class="notice ${p.quantity===0?'out':''}"><span class="notice-dot"></span><div><strong>${p.quantity===0?'Out of stock':'Low stock'}: ${esc(p.name)}</strong><span>${p.quantity===0?'No units remaining':`Only ${number(p.quantity)} units remaining · minimum ${number(p.minimumStock)}`}</span></div></div>`).join('') : `<div class="notice"><span class="notice-dot" style="background:var(--teal)"></span><div><strong>All clear</strong><span>No products currently need attention.</span></div></div>`}`;
  document.querySelector('.top-actions').appendChild(panel);
}

function animateMetrics() {
  document.querySelectorAll('[data-count]').forEach(el => {
    const target = Number(el.dataset.count); const isMoney = el.dataset.kind === 'money'; const start = performance.now(); const duration=550;
    const tick = now => { const p=Math.min(1,(now-start)/duration); const eased=1-Math.pow(1-p,3); const value=target*eased; el.textContent=isMoney?money(value):number(Math.round(value)); if(p<1) requestAnimationFrame(tick); };
    requestAnimationFrame(tick);
  });
}


function sideNavigation(active) {
  const items = [
    ['inventory', 'Inventory'],
    ['products', 'Products'],
    ['analytics', 'Analytics'],
    ['settings', 'Settings'],
  ];
  return `<aside class="sidebar">
    <div class="brand-mark"><span class="brand-logo">S</span><span>Stockify</span></div>
    <div class="side-label">Workspace</div>
    <nav class="side-nav">${items.map(([key,label]) => `<button class="side-item ${active===key?'active':''}" data-page="${key}"><span class="dot"></span>${label}</button>`).join('')}</nav>
    <div class="sidebar-user"><div class="avatar">${esc(initials(state.user.fullName))}</div><div style="min-width:0"><strong>${esc(state.user.fullName)}</strong><span>${esc(state.user.shopName)}</span></div></div>
  </aside>`;
}

function mobileNavigation(active) {
  return `<nav class="mobile-nav" aria-label="Workspace navigation">
    ${[['inventory','Inventory','▦'],['products','Products','□'],['analytics','Analytics','⌁'],['settings','Settings','⚙']].map(([key,label,symbol]) => `<button class="${active===key?'active':''}" data-page="${key}"><span>${symbol}</span>${label}</button>`).join('')}
  </nav>`;
}

function bindNavigation() {
  document.querySelectorAll('[data-page]').forEach(button => {
    button.onclick = () => {
      state.page = button.dataset.page;
      state.showNotifications = false;
      renderDashboard();
    };
  });
}

function commonTopbar(title, subtitle, actions = '') {
  return `<header class="topbar">
    <div class="topbar-title"><strong>${esc(title)}</strong><span>${esc(subtitle)}</span></div>
    <div class="top-actions">${actions}<button class="btn btn-soft btn-sm" id="logout-button">Sign out</button></div>
  </header>`;
}

function renderInventoryPage() {
  const s = state.summary || { totalProducts:0,totalUnits:0,lowStockProducts:0,inventoryValue:0,categoryBreakdown:[] };
  const cats = categories(); const notices = notifications();
  app.innerHTML = `<div class="app-shell">
    ${sideNavigation('inventory')}
    <div class="main">
      <header class="topbar">
        <div class="topbar-title"><strong>Inventory</strong><span>Track products, stock levels and pricing.</span></div>
        <div class="top-actions">
          <button class="icon-btn" id="notifications-button" aria-label="Notifications">♢${notices.length?'<span class="badge-dot"></span>':''}</button>
          <button class="icon-btn" id="refresh-button" aria-label="Refresh">↻</button>
          <button class="btn btn-amber" id="add-product">＋ <span class="hide-mobile">Add Product</span></button>
          <button class="btn btn-soft btn-sm" id="logout-button">Sign out</button>
        </div>
      </header>
      <main class="content">
        <section class="welcome enter"><div><h1>Welcome back, ${esc(state.user.fullName.split(' ')[0])}.</h1><p>${esc(state.user.shopName)} · Your inventory snapshot is ready.</p></div><div class="member-stack"><span class="member">${esc(initials(state.user.fullName))}</span><span class="member">OP</span><span class="member">+2</span></div></section>
        <section class="metrics">
          <div class="metric enter delay-1"><div class="metric-head"><span>Catalog</span><span class="metric-icon">▦</span></div><div class="metric-value" data-count="${s.totalProducts}">0</div><div class="metric-foot">Products being tracked</div></div>
          <div class="metric enter delay-1"><div class="metric-head"><span>Units on hand</span><span class="metric-icon">▤</span></div><div class="metric-value" data-count="${s.totalUnits}">0</div><div class="metric-foot">Across all categories</div></div>
          <div class="metric enter delay-2"><div class="metric-head"><span>Needs attention</span><span class="metric-icon">!</span></div><div class="metric-value" data-count="${s.lowStockProducts}">0</div><div class="metric-foot">Low or out of stock</div></div>
          <div class="metric enter delay-3"><div class="metric-head"><span>Inventory value</span><span class="metric-icon">₹</span></div><div class="metric-value" data-count="${s.inventoryValue}" data-kind="money">₹0</div><div class="metric-foot">Based on your unit prices</div></div>
        </section>
        <section class="grid-main">
          <div class="card enter delay-2">
            <div class="card-head"><div class="card-title"><h2>Inventory</h2><p>Manage quantities, pricing and current market comparisons.</p></div><div class="filters"><div class="search"><span>⌕</span><input class="input" id="search-input" value="${esc(state.search)}" placeholder="Search products…"></div><select class="input" id="category-filter"><option value="">All categories</option>${cats.map(c=>`<option value="${esc(c)}" ${state.category===c?'selected':''}>${esc(c)}</option>`).join('')}</select></div></div>
            <div class="table-wrap"><table><thead><tr><th>Product</th><th>Category</th><th>Stock</th><th style="text-align:right">Your price</th><th style="text-align:right">Market price</th><th>Updated</th><th style="text-align:right">Actions</th></tr></thead><tbody id="products-tbody"></tbody></table></div>
            <div id="mobile-products" class="mobile-list"></div>
            <div id="empty-state" class="empty hidden"><div class="empty-icon">▦</div><h3>${state.products.length ? 'No products match your filters' : 'Your inventory is empty'}</h3><p>${state.products.length ? 'Try a different search or category.' : 'Add your first product or load sample data to start tracking stock.'}</p>${state.products.length ? '' : '<div style="display:flex;gap:8px;justify-content:center"><button class="btn btn-primary" id="empty-add">Add product</button><button class="btn btn-soft" id="demo-data">Load demo data</button></div>'}</div>
          </div>
          <aside class="side-stack">
            <div class="card breakdown enter delay-2"><h3>Category breakdown</h3><p class="subtitle">Units and value by category</p><div id="breakdown-list"></div></div>
            <div class="card operator-note enter delay-3"><h3>Operator note</h3><p>Market prices are fetched only when you click “Check price”, helping avoid unnecessary API usage. Results are cached for about 15 minutes.</p></div>
          </aside>
        </section>
      </main>
    </div>
    ${mobileNavigation('inventory')}
  </div>`;

  renderProductAreas(); renderBreakdown(); animateMetrics(); updateNotificationPanel(); bindNavigation();
  document.querySelector('#search-input').addEventListener('input', e => { state.search=e.target.value; renderProductAreas(); });
  document.querySelector('#category-filter').addEventListener('change', e => { state.category=e.target.value; renderProductAreas(); });
  document.querySelector('#add-product').onclick = () => openProductModal();
  document.querySelector('#empty-add')?.addEventListener('click', () => openProductModal());
  document.querySelector('#demo-data')?.addEventListener('click', loadDemoData);
  document.querySelector('#notifications-button').onclick = e => { e.stopPropagation(); state.showNotifications=!state.showNotifications; updateNotificationPanel(); };
  document.querySelector('#refresh-button').onclick = refreshDashboard;
  document.querySelector('#logout-button').onclick = logout;
  document.addEventListener('click', closeNotificationsOnce, { once:true });
}

function renderDashboard() {
  if (state.page === 'products') return renderProductsPage();
  if (state.page === 'analytics') return renderAnalyticsPage();
  if (state.page === 'settings') return renderSettingsPage();
  return renderInventoryPage();
}

function productManageCard(p, index) {
  const s = statusInfo(p);
  return `<article class="manage-product enter" style="animation-delay:${Math.min(index*28,210)}ms">
    <div class="manage-product-head"><div><div class="product-name">${esc(p.name)}</div><div class="product-id">${esc(p.productId)}</div></div><span class="stock-status status-${s.cls}">${s.label}</span></div>
    <div class="manage-category"><span class="category-pill">${esc(p.category)}</span><span>${dateText(p.updatedAt)}</span></div>
    <div class="manage-numbers"><div><span>On hand</span><strong>${number(p.quantity)}</strong></div><div><span>Minimum</span><strong>${number(p.minimumStock)}</strong></div><div><span>Unit price</span><strong>${money(p.price)}</strong></div><div><span>Stock value</span><strong>${money(p.quantity*p.price)}</strong></div></div>
    ${stockMarkup(p)}
    <div class="manage-actions"><button class="btn btn-soft btn-sm" data-adjust="${p.id}">Adjust stock</button><button class="btn btn-soft btn-sm" data-edit="${p.id}">Edit</button><button class="btn btn-soft btn-sm danger-text" data-delete="${p.id}">Delete</button></div>
  </article>`;
}

function renderManageProducts() {
  const el = document.querySelector('#manage-products');
  if (!el) return;
  const list = filteredProducts();
  el.innerHTML = list.length ? list.map(productManageCard).join('') : `<div class="empty card span-all"><div class="empty-icon">□</div><h3>No products found</h3><p>${state.products.length?'Try changing your search or category filter.':'Add your first product to start building your catalog.'}</p></div>`;
  bindProductActions();
}

function renderProductsPage() {
  const cats = categories();
  app.innerHTML = `<div class="app-shell">
    ${sideNavigation('products')}
    <div class="main">
      ${commonTopbar('Products','Manage your product catalog.', '<button class="icon-btn" id="refresh-button" aria-label="Refresh">↻</button><button class="btn btn-amber" id="add-product">＋ <span class="hide-mobile">Add Product</span></button>')}
      <main class="content">
        <section class="page-hero enter"><div><span class="eyebrow">Catalog management</span><h1>Products</h1><p>Edit product details, pricing, thresholds and stock from one place.</p></div><div class="hero-stat"><strong>${number(state.products.length)}</strong><span>Total products</span></div></section>
        <section class="card product-toolbar enter delay-1"><div class="filters"><div class="search"><span>⌕</span><input class="input" id="products-search" value="${esc(state.search)}" placeholder="Search name or product ID…"></div><select class="input" id="products-category"><option value="">All categories</option>${cats.map(c=>`<option value="${esc(c)}" ${state.category===c?'selected':''}>${esc(c)}</option>`).join('')}</select></div><div class="toolbar-note">${number(filteredProducts().length)} shown</div></section>
        <section id="manage-products" class="manage-grid"></section>
      </main>
    </div>
    ${mobileNavigation('products')}
  </div>`;
  renderManageProducts(); bindNavigation();
  document.querySelector('#products-search').oninput=e=>{state.search=e.target.value;renderManageProducts();};
  document.querySelector('#products-category').onchange=e=>{state.category=e.target.value;renderManageProducts();};
  document.querySelector('#add-product').onclick=()=>openProductModal();
  document.querySelector('#refresh-button').onclick=refreshDashboard;
  document.querySelector('#logout-button').onclick=logout;
}

function renderAnalyticsPage() {
  const s = state.summary || { totalProducts:0,totalUnits:0,lowStockProducts:0,inventoryValue:0,categoryBreakdown:[] };
  const healthy = state.products.filter(p=>p.quantity>p.minimumStock).length;
  const low = state.products.filter(p=>p.quantity>0 && p.quantity<=p.minimumStock).length;
  const out = state.products.filter(p=>p.quantity===0).length;
  const maxCategory = Math.max(1,...(s.categoryBreakdown||[]).map(r=>r.value));
  const topProducts=[...state.products].sort((a,b)=>(b.quantity*b.price)-(a.quantity*a.price)).slice(0,5);
  const maxProduct=Math.max(1,...topProducts.map(p=>p.quantity*p.price));
  app.innerHTML=`<div class="app-shell">
    ${sideNavigation('analytics')}
    <div class="main">
      ${commonTopbar('Analytics','Understand stock health and inventory value.', '<button class="icon-btn" id="refresh-button" aria-label="Refresh">↻</button>')}
      <main class="content">
        <section class="page-hero enter"><div><span class="eyebrow">Inventory intelligence</span><h1>Analytics</h1><p>A live view of stock health, category value and your highest-value products.</p></div><div class="hero-stat"><strong>${money(s.inventoryValue)}</strong><span>Total inventory value</span></div></section>
        <section class="metrics analytics-metrics">
          <div class="metric enter delay-1"><div class="metric-head"><span>Healthy products</span><span class="metric-icon">✓</span></div><div class="metric-value">${number(healthy)}</div><div class="metric-foot">Above minimum stock</div></div>
          <div class="metric enter delay-1"><div class="metric-head"><span>Low stock</span><span class="metric-icon">!</span></div><div class="metric-value">${number(low)}</div><div class="metric-foot">At or below minimum</div></div>
          <div class="metric enter delay-2"><div class="metric-head"><span>Out of stock</span><span class="metric-icon">0</span></div><div class="metric-value">${number(out)}</div><div class="metric-foot">Need replenishment</div></div>
          <div class="metric enter delay-2"><div class="metric-head"><span>Average unit value</span><span class="metric-icon">₹</span></div><div class="metric-value">${s.totalUnits?money(s.inventoryValue/s.totalUnits):money(0)}</div><div class="metric-foot">Value ÷ units on hand</div></div>
        </section>
        <section class="analytics-grid">
          <div class="card analytics-card enter delay-2"><div class="section-heading"><div><h2>Value by category</h2><p>Share of current inventory value.</p></div></div><div class="analytics-bars">${(s.categoryBreakdown||[]).length?(s.categoryBreakdown||[]).map((r,i)=>`<div class="analytics-row"><div class="analytics-label"><strong>${esc(r.category)}</strong><span>${money(r.value)} · ${number(r.quantity)} units</span></div><div class="analytics-track"><div class="analytics-fill" style="width:${Math.max(4,(r.value/maxCategory)*100)}%;transition-delay:${i*60}ms"></div></div></div>`).join(''):'<p class="muted-copy">Add products to see category analytics.</p>'}</div></div>
          <div class="card analytics-card enter delay-3"><div class="section-heading"><div><h2>Highest-value products</h2><p>Quantity × your unit price.</p></div></div><div class="analytics-bars">${topProducts.length?topProducts.map((p,i)=>`<div class="analytics-row"><div class="analytics-label"><strong>${esc(p.name)}</strong><span>${money(p.quantity*p.price)}</span></div><div class="analytics-track"><div class="analytics-fill alt" style="width:${Math.max(4,((p.quantity*p.price)/maxProduct)*100)}%;transition-delay:${i*60}ms"></div></div></div>`).join(''):'<p class="muted-copy">No product data yet.</p>'}</div></div>
        </section>
      </main>
    </div>
    ${mobileNavigation('analytics')}
  </div>`;
  bindNavigation();
  document.querySelector('#refresh-button').onclick=refreshDashboard;
  document.querySelector('#logout-button').onclick=logout;
}

function renderSettingsPage() {
  const u=state.user;
  const locationReady=u.marketLatitude!=null && u.marketLongitude!=null;
  app.innerHTML=`<div class="app-shell">
    ${sideNavigation('settings')}
    <div class="main">
      ${commonTopbar('Settings','Manage your account and shop location.')}
      <main class="content settings-content">
        <section class="page-hero enter"><div><span class="eyebrow">Workspace settings</span><h1>Settings</h1><p>Your shop location is saved per account and is used only for location-sensitive market-price searches.</p></div><div class="location-status ${locationReady?'ready':'missing'}"><span></span><div><strong>${locationReady?'Location configured':'Location needed'}</strong><small>${locationReady?'Market pricing can use your shop area.':'Set coordinates below before checking prices.'}</small></div></div></section>
        <form id="settings-form" class="settings-grid">
          <section class="card settings-card enter delay-1"><div class="section-heading"><div><h2>Account</h2><p>Basic details shown throughout Stockify.</p></div></div><div class="settings-body"><div class="form-grid"><div class="field"><label>Full name</label><input class="input" name="fullName" required value="${esc(u.fullName)}"></div><div class="field"><label>Mobile</label><input class="input" name="mobile" required value="${esc(u.mobile)}"></div></div><div class="field"><label>Email</label><input class="input" value="${esc(u.email)}" disabled><small class="field-help">Email cannot be changed here.</small></div><div class="field"><label>Shop name</label><input class="input" name="shopName" required value="${esc(u.shopName)}"></div></div></section>
          <section class="card settings-card enter delay-2"><div class="section-heading"><div><h2>Shop location</h2><p>Each user can define a different location.</p></div></div><div class="settings-body"><div class="field"><label>PIN code</label><input class="input" name="marketPincode" inputmode="numeric" maxlength="6" placeholder="400001" value="${esc(u.marketPincode||'')}"><small class="field-help">Optional, but useful for precise availability.</small></div><div class="form-grid"><div class="field"><label>Latitude</label><input class="input" name="marketLatitude" type="number" step="any" placeholder="19.0760" value="${u.marketLatitude??''}"></div><div class="field"><label>Longitude</label><input class="input" name="marketLongitude" type="number" step="any" placeholder="72.8777" value="${u.marketLongitude??''}"></div></div><div class="settings-note"><strong>API key stays private.</strong><span>The app owner adds only <code>QUICKCOMMERCE_API_KEY</code> as a server environment variable/secret. Your location is stored with your own Stockify account.</span></div></div></section>
          <div class="settings-actions span-all"><button class="btn btn-primary" type="submit">Save settings</button></div>
        </form>
      </main>
    </div>
    ${mobileNavigation('settings')}
  </div>`;
  bindNavigation();
  document.querySelector('#logout-button').onclick=logout;
  const form=document.querySelector('#settings-form');
  form.onsubmit=async e=>{
    e.preventDefault();
    const button=form.querySelector('[type=submit]'); button.disabled=true; button.textContent='Saving…';
    const raw=Object.fromEntries(new FormData(form));
    try {
      const data=await api('/api/user/settings',{method:'PATCH',body:JSON.stringify(raw)});
      state.user=data.user; toast('Settings saved.'); renderSettingsPage();
    } catch(err) { toast(err.message,'error'); button.disabled=false; button.textContent='Save settings'; }
  };
}

function closeNotificationsOnce(e) { if (state.showNotifications && !e.target.closest('#notification-panel') && !e.target.closest('#notifications-button')) { state.showNotifications=false; updateNotificationPanel(); } }

async function refreshDashboard() {
  const btn=document.querySelector('#refresh-button'); btn.textContent='↻'; btn.style.animation='spin .7s linear infinite';
  try { await loadDashboardData(); renderDashboard(); toast('Inventory refreshed.'); } catch(err){ toast(err.message,'error'); } finally { if(btn) btn.style.animation=''; }
}
async function logout() { try { await api('/api/auth/logout',{method:'POST'}); } catch {} state.user=null; state.products=[]; state.marketPrices.clear(); state.page='inventory'; renderAuth('login'); }
async function loadDemoData() { try { await api('/api/demo-data',{method:'POST'}); await loadDashboardData(); renderDashboard(); toast('Demo inventory added.'); } catch(err){ toast(err.message,'error'); } }

function bindProductActions() {
  document.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => openProductModal(state.products.find(p=>p.id===Number(b.dataset.edit))));
  document.querySelectorAll('[data-adjust]').forEach(b => b.onclick = () => openAdjustModal(state.products.find(p=>p.id===Number(b.dataset.adjust))));
  document.querySelectorAll('[data-delete]').forEach(b => b.onclick = () => openDeleteModal(state.products.find(p=>p.id===Number(b.dataset.delete))));
  document.querySelectorAll('[data-market]').forEach(b => b.onclick = () => fetchMarketPrice(Number(b.dataset.market)));
}

async function fetchMarketPrice(id) {
  const p=state.products.find(x=>x.id===id); if(!p || state.marketLoading.has(id)) return;
  state.marketLoading.add(id); renderProductAreas();
  try {
    const data=await api(`/api/market-price?query=${encodeURIComponent(p.name)}&platform=Flipkart`); state.marketPrices.set(id,data); toast(`Market price updated for ${p.name}.`);
  } catch(err) { toast(err.message,'error'); }
  finally { state.marketLoading.delete(id); renderProductAreas(); }
}

function modal(html) {
  modalRoot.innerHTML=`<div class="modal-backdrop" id="modal-backdrop">${html}</div>`;
  document.querySelector('#modal-backdrop').addEventListener('mousedown', e => { if(e.target.id==='modal-backdrop') closeModal(); });
  document.querySelectorAll('[data-close-modal]').forEach(b=>b.onclick=closeModal);
}
function closeModal(){ modalRoot.innerHTML=''; }

function openProductModal(product=null) {
  modal(`<section class="modal" role="dialog" aria-modal="true"><div class="modal-head"><div><h3>${product?'Edit product':'Add product'}</h3><p>${product?'Update product details and thresholds.':'Create a new inventory item.'}</p></div><button class="close-btn" data-close-modal>×</button></div><form id="product-form"><div class="modal-body"><div class="form-grid"><div class="field"><label>Product ID</label><input class="input" name="productId" required value="${esc(product?.productId||'')}" placeholder="SKU-001"></div><div class="field"><label>Category</label><input class="input" name="category" required value="${esc(product?.category||'')}" placeholder="Electronics"></div></div><div class="field"><label>Product name</label><input class="input" name="name" required value="${esc(product?.name||'')}" placeholder="Wireless Mouse"></div><div class="form-grid"><div class="field"><label>Quantity</label><input class="input" type="number" min="0" step="1" name="quantity" required value="${product?.quantity??0}"></div><div class="field"><label>Minimum stock</label><input class="input" type="number" min="0" step="1" name="minimumStock" required value="${product?.minimumStock??0}"></div></div><div class="field"><label>Unit price (INR)</label><input class="input" type="number" min="0" step="0.01" name="price" required value="${product?.price??0}"></div></div><div class="modal-foot"><button type="button" class="btn btn-soft" data-close-modal>Cancel</button><button type="submit" class="btn btn-primary">${product?'Save changes':'Add product'}</button></div></form></section>`);
  const form=document.querySelector('#product-form'); form.onsubmit=async e=>{e.preventDefault(); const submit=form.querySelector('[type=submit]'); submit.disabled=true; submit.textContent='Saving…'; const raw=Object.fromEntries(new FormData(form)); const payload={...raw,quantity:Number(raw.quantity),minimumStock:Number(raw.minimumStock),price:Number(raw.price)}; try{ await api(product?`/api/products/${product.id}`:'/api/products',{method:product?'PATCH':'POST',body:JSON.stringify(payload)}); closeModal(); await loadDashboardData(); renderDashboard(); toast(product?'Product updated.':'Product added successfully.'); }catch(err){toast(err.message,'error'); submit.disabled=false; submit.textContent=product?'Save changes':'Add product';}};
}

function openAdjustModal(product) {
  let delta=0;
  modal(`<section class="modal" role="dialog" aria-modal="true"><div class="modal-head"><div><h3>Adjust stock</h3><p>${esc(product.name)} · ${esc(product.productId)}</p></div><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div class="adjust-grid">${[1,5,10,-1,-5,-10].map(n=>`<button class="btn btn-soft" type="button" data-delta="${n}">${n>0?'+':''}${n}</button>`).join('')}</div><div class="field"><label>Custom adjustment</label><input class="input" id="custom-delta" type="number" step="1" value="0"></div><div class="adjust-preview"><div><span>Current</span><strong>${number(product.quantity)}</strong></div><div><span>Adjustment</span><strong id="delta-preview">0</strong></div><div><span>New stock</span><strong id="new-preview">${number(product.quantity)}</strong></div></div></div><div class="modal-foot"><button class="btn btn-soft" data-close-modal>Cancel</button><button class="btn btn-primary" id="apply-adjust">Apply adjustment</button></div></section>`);
  const custom=document.querySelector('#custom-delta'); const refresh=()=>{document.querySelector('#delta-preview').textContent=`${delta>0?'+':''}${delta}`; document.querySelector('#new-preview').textContent=number(product.quantity+delta); document.querySelector('#new-preview').style.color=product.quantity+delta<0?'var(--red)':'';};
  document.querySelectorAll('[data-delta]').forEach(b=>b.onclick=()=>{delta=Number(b.dataset.delta);custom.value=delta;refresh();}); custom.oninput=()=>{delta=Number(custom.value||0);refresh();};
  document.querySelector('#apply-adjust').onclick=async()=>{ if(!Number.isInteger(delta))return toast('Adjustment must be a whole number.','error'); if(product.quantity+delta<0)return toast('Stock cannot go below zero.','error'); if(delta===0)return toast('Choose a stock adjustment.','error'); try{await api(`/api/products/${product.id}/adjust-stock`,{method:'POST',body:JSON.stringify({delta})}); closeModal(); await loadDashboardData(); renderDashboard(); toast('Stock updated.');}catch(err){toast(err.message,'error');}};
}
function openDeleteModal(product) {
  modal(`<section class="modal" role="dialog" aria-modal="true"><div class="modal-head"><div><h3>Delete product?</h3><p>This will permanently remove ${esc(product.name)} from your inventory.</p></div><button class="close-btn" data-close-modal>×</button></div><div class="modal-body"><div style="padding:14px;border:1px solid #fee2e2;background:#fef2f2;border-radius:11px"><strong style="font-size:12px">${esc(product.name)}</strong><div class="product-id" style="margin-top:5px">${esc(product.productId)}</div></div></div><div class="modal-foot"><button class="btn btn-soft" data-close-modal>Cancel</button><button class="btn btn-danger" id="confirm-delete">Delete product</button></div></section>`);
  document.querySelector('#confirm-delete').onclick=async()=>{try{await api(`/api/products/${product.id}`,{method:'DELETE'}); state.marketPrices.delete(product.id); closeModal(); await loadDashboardData(); renderDashboard(); toast('Product deleted.');}catch(err){toast(err.message,'error');}};
}

async function boot() {
  try { const data=await api('/api/auth/me'); state.user=data.user; await loadDashboardData(); renderDashboard(); }
  catch { renderAuth('login'); }
}
boot();
